import React, { useContext} from 'react';
import { CounterContext } from '../context/Counter';

const Counter = () =>{
    const contextAPI=useContext(CounterContext)
    return(<div>
        <button onClick={()=>contextAPI.setCount(contextAPI.count+1)}>Increament</button>
        <button onClick={()=>contextAPI.setCount(contextAPI.count-1)}>Decreament</button>
    </div>);
};

export default Counter;